#!/usr/bin/env node
require('./index.js')